figure (1);
%muestra el primer diagrama de bloques para el ejericio 1
freqz([1/2,1/2]);
figure (2);
%muestra el segundo diagrama de bloques para el ejericio 1
freqz([1/2,-1/2]);
figure (3);
%muestra el tercer diagrama de bloques para el ejericio 1
freqz([1/8,3/8,3/8,1/8]);

